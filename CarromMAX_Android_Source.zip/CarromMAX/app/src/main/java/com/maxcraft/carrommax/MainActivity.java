package com.maxcraft.carrommax;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import java.util.*;
import java.text.DecimalFormat;

/**
 * Carrom MAX: a standalone four-board practice simulator.
 * This does not control or automate any third-party/online Carrom game.
 */
public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        setContentView(new CarromDashboard(this));
    }

    static class CarromDashboard extends View {
        final Paint p = new Paint(3);
        final Handler handler = new Handler(Looper.getMainLooper());
        final Board[] boards = new Board[4];
        final DecimalFormat df = new DecimalFormat("0.0");
        long last = System.nanoTime();
        boolean autoPlay = false, autoQueue = false, showAim = true, ai = true;
        float speed = 1f;
        int selected = 0;
        String toast = "Tap a board to select it • Drag striker to aim • Tap SHOT";
        float density;
        Runnable ticker = new Runnable() {
            @Override public void run() {
                long now = System.nanoTime();
                float dt = Math.min(.05f, (now-last)/1_000_000_000f) * speed;
                last = now;
                if (autoPlay) {
                    if (autoQueue) {
                        Board b = boards[selected];
                        b.autoTimer += dt;
                        if (b.autoTimer > 1.4f) {
                            int fired = selected;
                            shoot(fired, true);
                            b.autoTimer = 0;
                            selected = (selected + 1) % boards.length;
                        }
                    } else {
                        for (Board b : boards) b.autoTimer += dt;
                        for (int i=0;i<boards.length;i++) {
                            Board b=boards[i];
                            if (b.autoTimer > 1.4f) { shoot(i, true); b.autoTimer=0; }
                        }
                    }
                }
                for (Board b:boards) b.update(dt);
                invalidate();
                handler.postDelayed(this, 16);
            }
        };

        CarromDashboard(Activity a) {
            super(a);
            density = getResources().getDisplayMetrics().density;
            for (int i=0;i<4;i++) boards[i]=new Board(i);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            handler.post(ticker);
        }
        float dp(float x) { return x*density; }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            c.drawColor(Color.rgb(7,17,14));
            float w=getWidth(), h=getHeight();
            float top=dp(42), bottom=dp(44), gap=dp(8), outer=dp(8);
            drawHeader(c,w);
            float areaH=h-top-bottom-outer;
            float bw=(w-outer*2-gap)/2f, bh=(areaH-gap)/2f;
            for(int i=0;i<4;i++) {
                int col=i%2,row=i/2;
                float x=outer+col*(bw+gap), y=top+row*(bh+gap);
                drawBoard(c,boards[i],x,y,bw,bh,i==selected);
            }
            drawFooter(c,w,h);
        }

        void drawHeader(Canvas c,float w) {
            p.setColor(Color.rgb(12,34,26)); c.drawRect(0,0,w,dp(42),p);
            p.setColor(Color.rgb(63,230,139)); p.setTextSize(dp(20)); p.setTypeface(Typeface.create("sans-serif-black",0));
            c.drawText("CARROM MAX",dp(12),dp(27),p);
            p.setTextSize(dp(10)); p.setTypeface(Typeface.DEFAULT_BOLD); p.setColor(Color.WHITE);
            c.drawText("4-BOARD PRACTICE LAB",dp(142),dp(25),p);
            p.setTextAlign(Paint.Align.RIGHT);
            c.drawText("SPEED "+df.format(speed)+"x",w-dp(12),dp(25),p);
            p.setTextAlign(Paint.Align.LEFT);
        }

        void drawBoard(Canvas c,Board b,float x,float y,float w,float h,boolean active) {
            p.setColor(active?Color.rgb(54,220,132):Color.rgb(45,84,66));
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(active?dp(3):dp(1.5f));
            c.drawRoundRect(x,y,x+w,y+h,dp(12),dp(12),p); p.setStyle(Paint.Style.FILL);
            float pad=Math.min(w,h)*.09f;
            float bx=x+pad, by=y+pad, bw=w-2*pad, bh=h-2*pad;
            p.setColor(Color.rgb(186,112,52)); c.drawRoundRect(bx,by,bx+bw,by+bh,dp(7),dp(7),p);
            float rim=dp(5);
            p.setColor(Color.rgb(248,216,160)); c.drawRoundRect(bx+rim,by+rim,bx+bw-rim,by+bh-rim,dp(4),dp(4),p);
            float ix=bx+rim+dp(3), iy=by+rim+dp(3), iw=bw-2*(rim+dp(3)), ih=bh-2*(rim+dp(3));
            p.setColor(Color.rgb(244,222,179)); c.drawRect(ix,iy,ix+iw,iy+ih,p);
            // pockets
            float pr=Math.min(iw,ih)*.055f;
            p.setColor(Color.rgb(28,22,18));
            c.drawCircle(ix,iy,pr,p); c.drawCircle(ix+iw,iy,pr,p);
            c.drawCircle(ix,iy+ih,pr,p); c.drawCircle(ix+iw,iy+ih,pr,p);
            // centre rings
            p.setColor(Color.rgb(191,65,50)); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1));
            c.drawCircle(ix+iw/2,iy+ih/2,Math.min(iw,ih)*.13f,p);
            c.drawCircle(ix+iw/2,iy+ih/2,Math.min(iw,ih)*.08f,p);
            p.setStyle(Paint.Style.FILL);
            // baseline
            p.setColor(Color.rgb(174,66,46)); p.setStrokeWidth(dp(1.5f));
            c.drawLine(ix+iw*.17f,iy+ih*.79f,ix+iw*.83f,iy+ih*.79f,p);
            c.drawLine(ix+iw*.17f,iy+ih*.21f,ix+iw*.83f,iy+ih*.21f,p);
            float r=Math.min(iw,ih)*.035f;
            // coins in a compact ring
            if(b.coins.isEmpty()) b.resetCoins(ix,iy,iw,ih,r);
            for(Coin coin:b.coins) {
                p.setColor(coin.color); c.drawCircle(ix+coin.x*iw,iy+coin.y*ih,r,p);
                p.setColor(Color.argb(100,0,0,0)); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(.7f));
                c.drawCircle(ix+coin.x*iw,iy+coin.y*ih,r*.68f,p); p.setStyle(Paint.Style.FILL);
            }
            float sx=ix+b.strikerX*iw, sy=iy+ih*.79f;
            p.setColor(Color.rgb(35,111,232)); c.drawCircle(sx,sy,r*1.3f,p);
            p.setColor(Color.WHITE); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1));
            c.drawCircle(sx,sy,r*.9f,p); p.setStyle(Paint.Style.FILL);
            if(showAim && active) {
                p.setColor(Color.rgb(20,160,93)); p.setStrokeWidth(dp(2));
                c.drawLine(sx,sy,sx+b.aimX*iw*.35f,sy-b.aimY*ih*.35f,p);
                p.setColor(Color.WHITE); p.setTextSize(dp(9)); p.setTypeface(Typeface.DEFAULT_BOLD);
                c.drawText("AIM",ix+dp(5),iy+dp(12),p);
            }
            // compact board status
            p.setColor(Color.rgb(7,28,19)); c.drawRoundRect(x+dp(5),y+dp(5),x+dp(94),y+dp(24),dp(5),dp(5),p);
            p.setColor(Color.WHITE); p.setTextSize(dp(10)); p.setTypeface(Typeface.DEFAULT_BOLD);
            c.drawText("BOARD "+(b.id+1),x+dp(10),y+dp(18),p);
            p.setTextSize(dp(9)); p.setColor(Color.rgb(14,53,36));
            c.drawRect(x+dp(5),y+h-dp(20),x+w-dp(5),y+h-dp(4),p);
            p.setColor(Color.WHITE);
            c.drawText("Score "+b.score+"  •  Pocketed "+b.pocketed+"  •  Miss "+b.misses,x+dp(10),y+h-dp(9),p);
        }

        void drawFooter(Canvas c,float w,float h) {
            float y=h-dp(39);
            p.setColor(Color.rgb(12,34,26)); c.drawRect(0,y,w,h,p);
            p.setColor(Color.WHITE); p.setTextSize(dp(10)); p.setTypeface(Typeface.DEFAULT_BOLD);
            String s=(autoPlay?"AUTO PLAY ON":"AUTO PLAY OFF")+"   •   "+(autoQueue?"AUTO QUEUE ON":"AUTO QUEUE OFF")+"   •   AI "+(ai?"ON":"OFF")+"   •   "+(showAim?"AIM ON":"AIM OFF");
            c.drawText(s,dp(10),y+dp(15),p);
            p.setColor(Color.rgb(115,226,160)); p.setTextSize(dp(9));
            c.drawText("Controls: tap board to select • tap bottom bar for options • double-tap board to shoot",dp(10),y+dp(29),p);
        }

        void shoot(int index,boolean automatic) {
            Board b=boards[index];
            if(b.coins.isEmpty()) b.resetCoins(.1f,.1f,.8f,.8f,.03f);
            b.shots++;
            // practice simulation: nudge the nearest coin toward a pocket-ish direction.
            Random rnd=new Random(System.nanoTime()+index*997L+b.shots);
            float chance=automatic ? (ai?.42f:.34f) : .30f;
            if(rnd.nextFloat()<chance && !b.coins.isEmpty()) {
                b.coins.remove(b.coins.size()-1);
                b.score+=10; b.pocketed++;
                toast="Board "+(index+1)+": practice pocket!";
            } else {
                b.misses++;
                toast="Board "+(index+1)+": shot simulated";
            }
            b.strikerX = .22f + rnd.nextFloat()*.56f;
            b.aimX = (rnd.nextFloat()-.5f)*1.5f;
            b.aimY = .3f+rnd.nextFloat()*.7f;
            if(b.coins.isEmpty()) {
                b.score+=20;
                b.resetCoins(.1f,.1f,.8f,.8f,.03f);
                toast="Board "+(index+1)+": round complete! +20";
            }
            invalidate();
        }

        @Override public boolean onTouchEvent(android.view.MotionEvent e) {
            float w=getWidth(), h=getHeight();
            float top=dp(42), bottom=dp(44), gap=dp(8), outer=dp(8);
            float areaH=h-top-bottom-outer, bw=(w-outer*2-gap)/2f, bh=(areaH-gap)/2f;
            if(e.getAction()==MotionEvent.ACTION_DOWN) {
                if(e.getY() < dp(42)) {
                    float[] speeds = new float[]{1f,2f,4f,6f,8f,10f};
                    int idx=0;
                    for(int i=0;i<speeds.length;i++) if(Math.abs(speed-speeds[i])<0.01f) idx=i;
                    speed=speeds[(idx+1)%speeds.length];
                    toast="Simulation speed: "+df.format(speed)+"x";
                    invalidate(); return true;
                }
                if(e.getY()>h-dp(39)) {
                    // Cycle controls by tapping footer.
                    if(e.getX()<w*.25f) autoPlay=!autoPlay;
                    else if(e.getX()<w*.50f) autoQueue=!autoQueue;
                    else if(e.getX()<w*.72f) ai=!ai;
                    else showAim=!showAim;
                    toast="Settings updated"; invalidate(); return true;
                }
                int col=e.getX()<(w/2f)?0:1;
                int row=e.getY()<(top+bh)?0:1;
                selected=row*2+col;
                downX=e.getX(); downY=e.getY();
                if(e.getY()>top+row*(bh+gap)+bh*.65f) {
                    Board b=boards[selected];
                    b.strikerX=Math.max(.18f,Math.min(.82f,(e.getX()-(col*(bw+gap)+outer))/(bw)));
                }
                invalidate(); return true;
            }
            if(e.getAction()==MotionEvent.ACTION_UP) {
                if(Math.abs(e.getX()-downX)<dp(12) && Math.abs(e.getY()-downY)<dp(12)) {
                    long now=System.currentTimeMillis();
                    if(now-lastTap<350) shoot(selected,false);
                    else { toast="Board "+(selected+1)+" selected • double tap to shoot"; }
                    lastTap=now;
                } else {
                    Board b=boards[selected];
                    b.aimX=(e.getX()-downX)/Math.max(1,bw);
                    b.aimY=(downY-e.getY())/Math.max(1,bh);
                    toast="Aim adjusted for Board "+(selected+1);
                }
                invalidate(); return true;
            }
            return true;
        }
        float downX,downY; long lastTap=0;

        static class Board {
            int id,score=0,pocketed=0,misses=0,shots=0;
            float strikerX=.5f,aimX=0,aimY=.6f,autoTimer=0;
            ArrayList<Coin> coins=new ArrayList<>();
            Board(int id){this.id=id;}
            void resetCoins(float x,float y,float w,float h,float r) {
                coins.clear();
                coins.add(new Coin(.50f,.48f,Color.rgb(195,39,45)));
                for(int i=0;i<6;i++) {
                    double a=Math.PI*2*i/6;
                    coins.add(new Coin(.50f+(float)Math.cos(a)*.075f,.48f+(float)Math.sin(a)*.075f,
                        i%2==0?Color.rgb(38,38,38):Color.rgb(239,239,224)));
                }
            }
            void update(float dt) { /* discrete practice simulator; board states remain independent */ }
        }
        static class Coin {
            float x,y; int color;
            Coin(float x,float y,int color){this.x=x;this.y=y;this.color=color;}
        }
    }
}
