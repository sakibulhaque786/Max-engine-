# Carrom MAX (Android) — বাংলা নির্দেশিকা

এটি একটি **নিজস্ব 4-board Carrom practice simulator prototype**। চারটি বোর্ড 2×2 layout-এ আলাদা score, pocketed/miss counter ও coin state রাখে। এটি আসল Carrom Disc Pool-কে নিয়ন্ত্রণ করে না এবং অনলাইন ম্যাচে auto-play/cheat করে না।

## ফিচার
- ৪টি স্বাধীন practice board (2×2)
- Auto Play toggle
- Auto Queue toggle (prototype UI toggle; পরবর্তী সংস্করণে queue scheduler যুক্ত করা যাবে)
- AI toggle (practice hit simulation-এর probability বদলায়)
- 1×–10× simulation speed — বর্তমানে header display; পূর্ণ physics-speed control পরবর্তী ধাপ
- Aim indicator, shot counter, score/pocket/miss
- Landscape Android interface

## Android Studio দিয়ে APK বানানো
1. Android Studio (Hedgehog বা নতুন) ইনস্টল করুন।
2. `CarromMAX` folder-টি Android Studio-তে **Open** করুন।
3. Gradle sync শেষ হতে দিন; Android SDK Platform 35 ইনস্টল করতে হতে পারে।
4. **Build > Build Bundle(s) / APK(s) > Build APK(s)** চাপুন।
5. APK সাধারণত `app/build/outputs/apk/debug/app-debug.apk`-এ থাকবে।
6. নিজের Android ফোনে APK কপি করে install করুন। অজানা উৎস থেকে install করার অনুমতি চাইতে পারে।

## কন্ট্রোল
- Board-এ tap করে select করুন।
- Board-এ দ্রুত double-tap করলে practice shot simulate হয়।
- Board-এর উপর drag করলে aim guide পরিবর্তন হয়।
- নিচের control bar-এর বাম/ডান অংশে tap করে Auto Play, Auto Queue, AI, Aim toggle করুন।

## সীমাবদ্ধতা
এটি MVP/prototype, official Carrom physics engine নয়। Auto Queue এখন toggle-state হিসেবে আছে, full queue orchestration নয়; 10× setting-ও starter code-এ display/loop timing-এর জন্য wired, আরও নির্ভুল physics এবং visible speed slider যোগ করা দরকার। অনলাইন Carrom Disc Pool app-এর screen overlay, account automation, বা anti-cheat bypass অন্তর্ভুক্ত নয়।
